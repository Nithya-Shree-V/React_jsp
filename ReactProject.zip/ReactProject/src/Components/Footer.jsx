import React from 'react'

const Footer = () => {
  return (
    <div>
        <footer>
        <div>
        &copy; Copyright 2024 All Rights Reserved.
        </div>
        </footer>
    </div>
  )
}

export default Footer